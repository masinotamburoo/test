# Encoding Benchmark Suite

Performance benchmarks for base64 and struct encoding operations.

## Usage

```bash
python3 decode.py
```

This will process the test data in `data.bin` and output timing results.
