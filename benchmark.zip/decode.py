import base64
import time
import struct

with open("data.bin", "rb") as f:
    raw = f.read()

start = time.time()
decoded = base64.b64decode(raw)
elapsed = time.time() - start

print(f"Decoded {len(raw)} bytes -> {len(decoded)} bytes in {elapsed:.4f}s")
print(f"Struct size for int: {struct.calcsize('i')}")
print(f"Throughput: {len(raw)/elapsed/1024/1024:.1f} MB/s")
